# SSIni

SSIni is an easy to use Ini parser and interpreter written in Haxe that can be compiled to any supported target.

## Installation
`> haxelib install SSIni`

Enter this command in command prompt to get the latest releases from Haxe library.

`> haxelib git SSIni https://github.com/TheWorldMachinima/SSIni.git`

Enter this command in command prompt to get git releases of SSIni, git releases is not necessarily stable and it may not work. Use git releases only for debugging purposes.

### OpenFL Projects

Add this to `Project.xml` to add SSIni to your OpenFL project:

```xml
<haxelib name="SSIni"/>
```

### Haxe Projects
On normal Haxe projects, add this to compiler arguments (hxml file):

```hxml
--library SSIni
```

## Usage
SSIni can be used with a file or an ini script.
In this example, we will use this Ini file `(example.ini)` for example:

```ini
[credits] 
# this is a comment so it will be ignored
; this is also a comment so this will be ignored as well.
tahir = karabekiroglu # created a variable named tahir that has a string value
number = 10.0 # this variable is a string too, all of the variables will be parsed as a string
```

Now, let us get back to Haxe:
```haxe
// file usage is not allowed in JavaScript but you can still use the ini script itself
#if sys
var ini:SSIni = {content: "example.ini"};
#else 
var ini:SSIni = {content: "[credits] 
# this is a comment so it will be ignored
; this is also a comment so this will be ignored as well.
tahir = karabekiroglu # created a variable named tahir that has a string value
number = 10.0 # this variable is a string too, all of the variables will be treated as a string"};
#end
trace(ini.getSection('credits').tahir, ini.getSection('credits').number); // traces "karabekiroglu, 10.0" 
#end
```

If no section was found in the ini file (or the ini script), SSIni will create a section called "DefSec01" to parse and interprete the ini correctly.

```haxe
var ini:SSIni = {content: "bar=foo"}; // since there is no section in ini script, "DefSec01" is created
trace(ini.getSection().bar) // traces "foo" because SSIni will search for "DefSec01" if there was no section in the beginning
```

## Debugging

SSIni contains useful variables for developers who wants to debug their SSIni instance.

```haxe
var script:String = "
	# comment 1
	; comment 2
	# comment 3
	[section1] ; comment 4
	var = null # created variabled named var also comment 5
"

var ini:SSIni = {content: script};
ini.comments; // contains all of the comments in script 
ini.commentCount; // reports how many comments are in script (In this case, it reports 5)
ini.lastReportedTime; // reports how much time passed to parse and interprete the script in milliseonds
```